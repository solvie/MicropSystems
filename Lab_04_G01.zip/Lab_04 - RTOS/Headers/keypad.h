void Row_Out_Col_In(void);
void Row_In_Col_Out(void);
int Get_Col_Pin_In_Reset_Mode(void);
int Get_Row_Pin_In_Reset_Mode(void);
void Read_KP_Value(void const *argument);
void start_kp_thread(void);
